package com.prestacao_de_servicos.prestacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrestacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
