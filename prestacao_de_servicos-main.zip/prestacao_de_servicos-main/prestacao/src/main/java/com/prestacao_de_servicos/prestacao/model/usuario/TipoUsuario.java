package com.prestacao_de_servicos.prestacao.model.usuario;

public enum TipoUsuario {
    CLIENTE,
    VENDEDOR,
    ADMIN
}
