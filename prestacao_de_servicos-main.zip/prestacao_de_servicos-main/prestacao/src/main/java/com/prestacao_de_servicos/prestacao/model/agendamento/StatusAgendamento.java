package com.prestacao_de_servicos.prestacao.model.agendamento;


public enum StatusAgendamento {
    PENDENTE,
    CONFIRMADO,
    CANCELADO
}