package com.prestacao_de_servicos.prestacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrestacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrestacaoApplication.class, args);
	}

}
