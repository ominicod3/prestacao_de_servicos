package com.prestacao_de_servicos.prestacao.model.agenda;

public enum StatusAgenda {
    LIVRE,
    RESERVADO,
    CONFIRMADO
}
